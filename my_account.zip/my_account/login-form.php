    <div class="container pt-5 mt-1">
<!--
    <div class="row">
        <div class="col-md-10">

                <h1 class="font-weight-light text-muted mt-6">WELCOME TO WJCW CROWDFUNDING</h1>

        </div>
    </div>
-->
    <div class="row">
    <div class="col-md-7 w-sm-100 pl-lg-0 pr-sm-0">
                <div class="container" style="background-color:green; color:white">
                            <ul class="ml-lg-5 ">
                                <h1 class="pt-4">Member Login</h1>
                                <section style="font-size:22px">
                                <li>World first welfare 2x2 via technology.</li>
                                <li>Benefits for everyone around the globe.</li>
                                <li>Help each other in good deeds (Al Quran).</li>
                                <li>We hope for a long and successful journey with you.</li>
                                <li>Established in 2020.</li>
                                </section>
                            </ul>
                </div>
    </div>	
	<div class="col-md-5 pl-lg-0">
	<div class="w-100">
		<div class="card w-100"  style="background-color:green">
			<div class="card-header">
				<h1 id="signin" >Sign In</h1>
				<!--<div class="d-flex justify-content-end social_icon mt-4">-->
				<!--	<span><i class="fab fa-facebook-square"></i></span>-->
				<!--	<span><i class="fab fa-google-plus-square"></i></span>-->
				<!--	<span><i class="fab fa-twitter-square"></i></span>-->
				<!--	<span><i class="fab fa-linkedin-square"></i></span>-->
				<!--</div>-->
			</div>
			<div class="card-body">
				<form>
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-user"></i></span>
						</div>
						<input type="email" name="email" class="form-control" id="email" placeholder="email address" required>
						
					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-lock"></i></span>
						</div>
						<input type="password" name="password" class="form-control" id="password" placeholder="password" required>
						
					</div>
					<div class="row align-items-center remember">
                        <input type="checkbox"><span id="rememberme">Remember Me</span>
					</div>
					<div class="form-group ">
<!--						<input >-->
						<input type="submit" name="Submit" value="Login" id="login" class="btn float-right login_btn font-weight-bold" style="width:150px;">
					</div>
				</form>
			</div>
			<div class="card-footer" style="padding: 5px;">
				<div class="d-flex justify-content-center links" id="card_bottom">
					Don't have an account?<a href="join-us.php" id="join_us">Join Us</a>
				</div>
				<div class="d-flex justify-content-center links" id="card_bottom">
					<a href="renew_membership.php" id="join_us">Renew Membership?</a>
				</div>
				<div class="d-flex justify-content-center">
					<a href="forget_password.php" id="forgot_password">Forgot your password?</a>
				</div>
			</div>
		</div>
	</div>
	</div>

	</div>
	</div>
