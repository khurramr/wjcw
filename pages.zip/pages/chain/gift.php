    <style>
    .center-text{
        text-align: right;
        font-weight: bold;
        color: seagreen;
    }
    .container_img {
    display: table;
    width: 100%;
        }


    </style>    

            <div class="row">

            <div class="column">
                <h4 class="center-text">01: A GIFT/DONATION: <br>
                First register and send gift/donate to became an active member
                </h4>
               <div class="container_img">
                    <img src="../assets/images/mlm/Gift1.jpg" style="width:50%; height:15%; float: right; " alt=""  title="Gift One">
                </div>
                <h4 class="center-text">02: SHARE WITH THE COMMUNITY<br>
                Help two or more become active members
                </h4>
                <div class="container_img">
                        
                    <img src="../assets/images/mlm/Gift2.jpg" style="width:70%; height:18%; float: right; " alt=""  title="Gift Two">
                </div>
                   <h4 class="center-text">03: RECEIVE GIFTS/ DONATIONS<br>
                   When they help two or more people become active members, <br>you will start receiving gifts and donations active member
                   </h4>
                <div class="container_img">                        
                    <img src="../assets/images/mlm/Gift3.jpg" style="width:70%; height:18%; float: right; "  alt=""  title="Gift Three">                
                </div>
            </div>

        </div>
