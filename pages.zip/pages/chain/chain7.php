    <style>
        .circle_img {
        border-radius: 50%;
        width: 100%;
        height: auto;
        }
    .circle_inside {
        border-radius: 50%;
        position: relative;
        left:68px;
        top: 1px;
/*
        max-width: 50%;
        height: auto;
        position: absolute;
        

        z-index:99999left: 200px;    
  transform: translate(-50%, -50%);
*/
        }
.cont {
  position: relative;
  text-align: center;
  color: white;
  font-weight: bold;
}
.centered {
  position: absolute;
  top: 63%;
  left: 25.5%;
  transform: translate(-50%, -50%);
}
.centered_img {
  position: absolute;
  top: 50%;
  left: 41.18%;
  transform: translate(-50%, -50%);
}    
.down {
  position: absolute;
  top: 150%;
    z-index:99999
/*  left: 41.18%;*/
/*  transform: translate(-50%, -50%);*/
}    
.up {
  position: absolute;
  top: -150%;
/*  left: 41.18%;*/
/*  transform: translate(-50%, -50%);*/
}    
.top_middle{
    position: relative; 
    right:66px; 
    top: 100%;
    z-index: 999999
}
.bottom_middle{
    position: relative; 
    right:-65px; 
    top:-100%;
    z-index: 999999
}
</style>    

<div class="container" style="color:seagreen">
    <h1 style="text-align:center; font-size:2vw;">WELCOME TO WJCW</h1>
 </div>
 <div class="row">
   <div class="col-sm-4"></div>
   <div class="col-sm-2">
       <div class="down">
               <img src="../assets/images/mlm/pps2.jpg" class="w-50 d-block circle_img " alt="" style="position: relative; top: 0; left:34px;">
            <img src="../assets/images/mlm/3.jpg" class="d-block" alt="" width="10%" style="position: relative; top: -22px; left:80px; border-radius: 50%;">
       </div>
      </div>
     <div class="col-sm-2">
           <div class="top_middle">
                <img src="../assets/images/mlm/pps3.jpg" class="w-50 d-block circle_img" alt="">
            <img src="../assets/images/mlm/1.jpg" class="d-block" alt="" width="10%" style="position: relative;  top:-21px; right:-45px; border-radius: 50%;">
           </div>
   </div>
<!--   style="position: relative; top: 0; left:50px; border-radius: 50%;"-->
   <div class="col-sm-2">
    <div class="down">   
    <img src="../assets/images/mlm/pps_9_375x450.jpg" class="circle_img" alt="" style="position: relative; right:172px; width:50%">
           <img src="../assets/images/mlm/4.jpg" class="d-block" alt="" width="10%" style="position: relative; top: -23px; right:126px; border-radius: 50%;">    
   </div>
   </div>
 </div>
  
 <div class="row">  
  <div class="col-sm-4"></div>
   <div class="col-sm-8 cont">
    <img src="../assets/images/mlm/pie11.png" class="w-75 d-block circle_img" alt="" id="pie_small">
       <div class="centered_img"><img src="../assets/images/mlm/pps_8_1_828x842.jpg" class="w-25 d-block circle_inside" alt=""></div>
      <div class="centered">YOU</div>
  </div>
  </div>
  

<div class="row">
  <div class="col-sm-3"></div>
  <div class="col-sm-2">
    <div class="up">                
              <img src="../assets/images/mlm/5.jpg" class="d-block " alt="" width="10%" style="position: relative;  top:140px; left:220px; border-radius: 50%; z-index:99999999">
      <img src="../assets/images/mlm/pps11.jpg" class="w-50 d-block circle_img" alt="" style="position: relative; left: 175px;">
  </div>
  </div>
  <div class="col-sm-2">
     <div class="bottom_middle">
               <img src="../assets/images/mlm/2.jpg" class="d-block" alt="" width="10%" style="position: relative; top:133px;  left:45px; border-radius:50%">
        <img src="../assets/images/mlm/pps13.jpeg" class="w-50 d-block circle_img" alt="">
      </div>
  </div>
  <div class="col-sm-2">
    <div class="up">                 
               <img src="../assets/images/mlm/6.jpg" class="d-block" alt="" width="10%" style="position: relative; top: 140px; right:0px; border-radius: 50%; z-index:999999">
    <img src="../assets/images/mlm/pps15.jpg" class="w-50 d-block circle_img" alt="" style="position: relative; top: 0; right:51px;">
  </div>
  </div>
</div>