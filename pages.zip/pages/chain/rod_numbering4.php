    <style>
.circle_img {
border-radius: 50%;
}

.circle_img1 {
    border-radius: 50%;
    width: 100%;
    height: auto;
    border: 5px solid green;
    right: 55px;
}

.div_main{ 
    position: relative;
}
        
        
.div_img_you{ 
    border-radius: 50%;
    position: absolute;
    Top: 0%;
}
        
        
.div_rod {
  position: absolute;
/*    margin-right:20%;    */
    
}
        
@media only screen and (max-width: 1600px) {
.div_img_01{ 
    position: absolute;
    Top: 0%;
    margin-left:-2.7%;
    margin-right:90%;
    
}
}

@media only screen and (max-width: 800px) {
.div_img_01{ 
    position: absolute;
    Top: 0%;
    margin-left:-5.7%;
    margin-right:90%;
    width:27%
}
}
        
        
@media only screen and (max-width: 600px) {
.div_img_01{ 
    position: absolute;
    Top: 0%;
    margin-left:-5.7%;
    margin-right:90%;
    width:27%
}
}
/*        
.shadow-circle{
    width:100px;
    height:100px;
	border-radius: 50%;
	border: 6px solid lightblue;
	-moz-background-clip: content;     /* Firefox 3.6 */
/*	-webkit-background-clip: content;  /* Safari 4? Chrome 6? *//*
	background-clip: content-box;      /* Firefox 4, Safari 5, Opera 10, IE 9 */
/*    background-color: lightgray*/
/*}
        
.shadow-circle:after {
    content: ' ';
    border-radius: 50%;
    border: 6px solid green;
    width: 110px;
    height: 110px;
    display: block;
    position: relative;
    top: -11px;
    left: -11px;
}        
.circle_img_01{ 
    border-radius: 50%;
    background-color: red;
    border: 4px solid #fff;
    box-shadow: 0 0 0 5px red;     
}
.circle_img_02{ 
      border: 5px solid;
      border-radius: 50%;
      border-color: red;
      z-index:9999;
     }
.circle_img_03{ 
      border: 5px solid;
      border-radius: 50%;
      border-color: green green #F39C12 #F39C12;
      z-index:9999;
     }
.circle_img_04{ 
/*      border: 5px solid;*/
   /*   border-radius: 50%;
/*      border-color: red red red red;*/
/*      z-index:9999;
     }
.circle_img_05{ 
      border: 5px solid;
      border-radius: 50%;
      border-color: maroon purple purple maroon;
      z-index:9999;
     }
.circle_img_06{ 
      border: 5px solid;
      border-radius: 50%;
      border-color: #667C26 maroon maroon #667C26;
      z-index:9999;
}


        
</style>    
    <div class="container">
        <div class="shadow-circle"></div>
    </div>
<div class="container-fluid">        
    <div class="container">    
        <div class="div_main">    
<!--
             <div class="div_img_you">
                    <img src="../assets/images/mlm/you.jpg" class="w-50 d-block " style="border-radius:50%">           
             </div>
-->
             <div class="div_rod">
                 <img src="../assets/images/mlm/rod.png">
             </div>
             <div class="div_img_01">
                    <img src="../assets/images/mlm/01_G.jpg" alt="" style="border-radius:50%; width:50%">
             </div>
         </div>
    </div>
</div>


<!--
        <br>
        <br>
        <br>
        <br>
        <img src="../assets/images/mlm/02_G.jpg" class="" alt="" style="z-index:9999; position:relative; left:733px; width:9%; border-radius:50%">
        <br>
        <br>
        <br>
        <br>
        <img src="../assets/images/mlm/03_G.jpg" class="" alt="" style="z-index:9999; position:relative; left:733px; width:9%">
        <br>
        <br>
        <br>
        <br>
        <img src="../assets/images/mlm/04_G.jpg" class="circle_img_04" alt="" style="z-index:9999; position:relative; left:733px; width:9%">
        <br>
        <br>
        <br>
        <br>
        <img src="../assets/images/mlm/05_dbl.jpg" class="<circle></circle>_img_05" alt="" style="z-index:9999; position:relative; left:733px; width:9%">
        <br>
        <br>
        <br>
        <br>
        <img src="../assets/images/mlm/06_G.jpg" class="" alt="" style="z-index:9999; position:relative; left:733px; width:9%">
-->
