    <style>
        .circle_img {
        border-radius: 50%;
        }
    .circle_inside {
        border-radius: 50%;
        position: relative;
        left:67px;
        top: 1px;

        }

            .circle_img1 {
        border-radius: 50%;
        width: 100%;
        height: auto;
        border: 5px solid green;
        right: 55px;
        }
        .cont {
  position: relative;
  text-align: center;
  color: white;
  font-weight: bold;
}
.centered {
  position: absolute;
  top: 63%;
  left: 25.5%;
  transform: translate(-50%, -50%);
}
.centered_img {
  position: absolute;
  top: 50%;
  left: 41.18%;
  transform: translate(-50%, -50%);
}    
.top_middle{
    position: relative; 
    right:51px; 
    top: 114%;
    z-index: 999999
}
.bottom_middle{
    position: relative; 
    right:-65px; 
    top:-111%;
    z-index: 999999
}
        
.circle_img_03{ 
      border: 5px solid;
      border-radius: 50%;
      border-color: green green #F39C12 #F39C12;
      z-index:9999;
     }
.circle_img_04{ 
      border: 5px solid;
      border-radius: 50%;
      border-color: #667C26  #667C26 #F39C12 #F39C12;
      z-index:9999;
     }
.circle_img_05{ 
      border: 5px solid;
      border-radius: 50%;
      border-color: maroon purple purple maroon;
      z-index:9999;
     }
.circle_img_06{ 
      border: 5px solid;
      border-radius: 50%;
      border-color: #667C26 maroon maroon #667C26;
      z-index:9999;
     }

</style>    


     <div class="row">  
      <div class="col-md-5">
        <img src="../assets/images/mlm/01.jpg" class="circle_img_04" alt="" style="z-index:9999; position:relative; left:815px; width:8%">
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <img src="../assets/images/mlm/02.jpg" class="circle_img_04" alt="" style="z-index:9999; position:relative; left:815px; width:8%">
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <img src="../assets/images/mlm/03.jpg" class="circle_img_04" alt="" style="z-index:9999; position:relative; left:815px; width:8%">
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <img src="../assets/images/mlm/04.jpg" class="circle_img_04" alt="" style="z-index:9999; position:relative; left:815px; width:8%">
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <img src="../assets/images/mlm/05.jpg" class="circle_img_04" alt="" style="z-index:9999; position:relative; left:815px; width:8%">
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <img src="../assets/images/mlm/06.jpg" class="circle_img_04" alt="" style="z-index:9999; position:relative; left:815px; width:8%">
      </div>
       <div class="col-sm-2 cont">
        <img src="../assets/images/mlm/rod.png" class="" alt="" style="">
        </div>
     </div>

