    <style>
        li{
          margin: 10px 0;
        }

        
        .row {
          display: flex;
        }

        /* Create three equal columns that sits next to each other */
        .column {
          flex: 45.33%;
          padding: 5px;
        }
        
        .circle_img {
        border-radius: 50%;
        max-width: 50%;
        height: auto;
        }

    .circle_inside {
        border-radius: 50%;
        max-width: 50%;
        height: auto;
          position: absolute;
          top: 60px;
          left: 105px;    

        }

        
    #pie_small
    {
      position: relative;
      top: 0;
      left: 0;
    }
    </style>    

<div class="row">
     <div class="col-md-3"></div>
   <div class="col-md-2">
  <img src="../assets/images/mlm/pps3.jpg" class="w-75 d-block circle_img" alt="" >
  </div>
  <div class="col-md-2">
    <img src="../assets/images/mlm/pps6.jpg" class="w-75 d-block circle_img" alt="">
  </div>
  <div class="col-md-2">
    <img src="../assets/images/mlm/pps5.jpg" class="w-75 d-block circle_img" alt="">
  </div>
 </div>
  
 <div class="row">  
<!-- <div class="container" id="main">-->
  <div class="col-md-4"></div>
   <div class="col-md-6" style="position: relative; left: 0; top: 0;">
    <img src="../assets/images/mlm/pie_small.jpg" class="w-50 d-block circle_img" alt="" id="pie_small">
    <img src="../assets/images/mlm/pps1.png" class="w-25 d-block circle_inside" alt="">
  </div>
  </div>
<!-- </div>-->
 

  <div class="row">
  <div class="col-md-3"></div>
  <div class="col-md-2">
    <img src="../assets/images/mlm/pps_8_375x450.jpg" class="w-75 d-block circle_img" alt="">
  </div>
  <div class="col-md-2">
    <img src="../assets/images/mlm/pps7.jpg" class="w-75 d-block circle_img" alt="">
  </div>
  <div class="col-md-2">
    <img src="../assets/images/mlm/pps_9_375x450.jpg" class="w-75 d-block circle_img" alt="">
  </div>

  </div>
