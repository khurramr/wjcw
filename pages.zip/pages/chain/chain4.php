    <style>
        .circle_img {
        border-radius: 50%;
        width: 100%;
        height: auto;
        }
    .circle_inside {
        border-radius: 50%;
/*
        max-width: 50%;
        height: auto;
        position: absolute;
        top: 180px;

        z-index:99999left: 200px;    
  transform: translate(-50%, -50%);
*/
        }
.cont {
  position: relative;
  text-align: center;
  color: white;
  font-weight: bold;
}
.centered {
  position: absolute;
  top: 76%;
  left: 26%;
  transform: translate(-50%, -50%);
}
.centered_img {
  position: absolute;
  top: 50%;
  left: 41.18%;
  transform: translate(-50%, -50%);
}    
.down {
  position: absolute;
  top: 103%;
    z-index:99999
/*  left: 41.18%;*/
/*  transform: translate(-50%, -50%);*/
}    
.up {
  position: absolute;
  top: -105%;
/*  left: 41.18%;*/
/*  transform: translate(-50%, -50%);*/
}    
.top_middle{
    position: relative; 
    right:66px; 
    top: 70%;
    z-index: 999999
}
.bottom_middle{
    position: relative; 
    right:-65px; 
    top:-70%;
    z-index: 999999
}
</style>    

<div class="container" style="color:seagreen">
    <h1 style="text-align:center; font-size:2vw;">WELCOME TO WJCW</h1>
 </div>
 <div class="row">
   <div class="col-sm-4"></div>
   <div class="col-sm-2">
       <div class="down">
               <img src="../assets/images/mlm/pps2.jpg" class="w-50 d-block circle_img " alt="" style="position: relative; top: 0; left:-5px;">
            <img src="../assets/images/mlm/3.jpg" class="d-block" alt="" width="10%" style="position: relative; top: 0; left:50px; border-radius: 50%;">
       </div>
      </div>
     <div class="col-sm-2">
           <div class="top_middle">
                <img src="../assets/images/mlm/pps3.jpg" class="w-50 d-block circle_img" alt="">
            <img src="../assets/images/mlm/1.jpg" class="d-block" alt="" width="10%" style="position: relative;  right:-45px; border-radius: 50%;">
           </div>
   </div>
<!--   style="position: relative; top: 0; left:50px; border-radius: 50%;"-->
   <div class="col-sm-2">
    <div class="down">   
    <img src="../assets/images/mlm/pps_9_375x450.jpg" class="w-50 d-block circle_img" alt="" style="position: relative; right:130px;">
           <img src="../assets/images/mlm/4.jpg" class="d-block" alt="" width="10%" style="position: relative; top: 0; right:80px; border-radius: 50%;">    
   </div>
   </div>
 </div>
  
 <div class="row">  
  <div class="col-sm-4"></div>
   <div class="col-sm-8 cont">
    <img src="../assets/images/mlm/pie10.png" class="w-75 d-block circle_img" alt="" id="pie_small">
       <div class="centered_img"><img src="../assets/images/mlm/pps_8_1_828x842.jpg" class="w-50 d-block circle_inside" alt=""></div>
      <div class="centered">YOU</div>
  </div>
  </div>
  

<div class="row">
  <div class="col-sm-3"></div>
  <div class="col-sm-2">
    <div class="up">                
              <img src="../assets/images/mlm/5.jpg" class="d-block " alt="" width="10%" style="position: relative;  left:168px; border-radius: 50%;">
      <img src="../assets/images/mlm/pps11.jpg" class="w-50 d-block circle_img" alt="" style="position: relative; left: 132px;">
  </div>
  </div>
  <div class="col-sm-2">
     <div class="bottom_middle">
               <img src="../assets/images/mlm/2.jpg" class="d-block" alt="" width="10%" style="position: relative; top: 0; left:50px; border-radius:50%">
        <img src="../assets/images/mlm/pps13.jpeg" class="w-50 d-block circle_img" alt="">
      </div>
  </div>
  <div class="col-sm-2">
    <div class="up">                 
               <img src="../assets/images/mlm/6.jpg" class="d-block" alt="" width="10%" style="position: relative; top: 0; right:-45px; border-radius: 50%;">
    <img src="../assets/images/mlm/pps12.jpg" class="w-50 d-block circle_img" alt="" style="position: relative; top: 0; right:9px;">
  </div>
  </div>
</div>