    <style>
.circle_img {
border-radius: 50%;
}

    .circle_img1 {
border-radius: 50%;
width: 100%;
height: auto;
border: 5px solid green;
right: 55px;
}
    .cont {
  position: relative;
  text-align: center;
  color: white;
  font-weight: bold;
}
        
        
.shadow-circle{
    width:100px;
    height:100px;
	border-radius: 50%;
	border: 6px solid lightblue;
	-moz-background-clip: content;     /* Firefox 3.6 */
	-webkit-background-clip: content;  /* Safari 4? Chrome 6? */
	background-clip: content-box;      /* Firefox 4, Safari 5, Opera 10, IE 9 */
/*    background-color: lightgray*/
}

.shadow-circle:after {
    content: ' ';
    border-radius: 50%;
    border: 6px solid green;
    width: 110px;
    height: 110px;
    display: block;
    position: relative;
    top: -11px;
    left: -11px;
}        
.circle_img_01{ 
    border-radius: 50%;
    background-color: red;
    border: 4px solid #fff;
    box-shadow: 0 0 0 5px red;     }
.circle_img_02{ 
      border: 5px solid;
      border-radius: 50%;
      border-color: red;
      z-index:9999;
     }
.circle_img_03{ 
      border: 5px solid;
      border-radius: 50%;
      border-color: green green #F39C12 #F39C12;
      z-index:9999;
     }
.circle_img_04{ 
      border: 5px solid;
      border-radius: 50%;
      border-color: red red red red;
      z-index:9999;
     }
.circle_img_05{ 
      border: 5px solid;
      border-radius: 50%;
      border-color: maroon purple purple maroon;
      z-index:9999;
     }
.circle_img_06{ 
      border: 5px solid;
      border-radius: 50%;
      border-color: #667C26 maroon maroon #667C26;
      z-index:9999;
     }


        
</style>    
    <div class="container">
        <div class="shadow-circle"></div>
    </div>
     <div class="row">  
      <div class="col-md-5">

        <img src="../assets/images/mlm/01_dbl.jpg" class="" alt="" style="z-index:9999; position:relative; left:730px; width:10%">
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <img src="../assets/images/mlm/02_dbl.jpg" class="" alt="" style="z-index:9999; position:relative; left:730px; width:10%; border-radius:50%">
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <img src="../assets/images/mlm/03_dbl.jpg" class="" alt="" style="z-index:9999; position:relative; left:730px; width:10%">
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <img src="../assets/images/mlm/04_dbl.jpg" class="circle_img_04" alt="" style="z-index:9999; position:relative; left:730px; width:10%">
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <img src="../assets/images/mlm/05_dbl.jpg" class="<circle></circle>_img_05" alt="" style="z-index:9999; position:relative; left:730px; width:10%">
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <img src="../assets/images/mlm/06_dbl.jpg" class="" alt="" style="z-index:9999; position:relative; left:730px; width:10%">
      </div>
       <div class="col-sm-2 cont">
        <img src="../assets/images/mlm/rod.png" class="" alt="" style="">
        </div>
     </div>

