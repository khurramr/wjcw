    <style>
        .circle_img {
        border-radius: 50%;
        width: 100%;
        height: auto;
        }
    .circle_inside {
        border-radius: 50%;
        position: relative;
        left:82px;
        top: 1px;
/*
        max-width: 50%;
        height: auto;
        position: absolute;
        

        z-index:99999left: 200px;    
  transform: translate(-50%, -50%);
*/
        }
.cont {
  position: relative;
  text-align: center;
  color: white;
  font-weight: bold;
}
.centered {
  position: absolute;
  top: 63%;
  left: 25.5%;
  transform: translate(-50%, -50%);
}
.centered_img {
  position: absolute;
  top: 50%;
  left: 41.6%;
  transform: translate(-50%, -50%);
}    
.top_middle{
    position: relative; 
    top: 158%;
    z-index: 999999
}
.bottom_middle{
    position: relative; 
    right:217px; 
    top:-158%;
    z-index: 999999
}
.bottom_right{
    position: relative; 
    right:290px; 
    top:-114%;
    z-index: 999999
}
</style>    

<div class="container" style="color:seagreen">
    <h1 style="text-align:center; font-size:2vw;">WELCOME TO WJCW</h1>
 </div>
 <div class="row">
   <div class="col-sm-3"></div>
   <div class="col-sm-2">        
              
               <img src="../assets/images/mlm/pps13.jpeg" class="circle_img " alt="" style="position: relative; top: 134%; right:128px; width:43%; z-index:9999">
            <img src="../assets/images/mlm/3.jpg" class="d-block" alt="" width="10%" style="position: relative; top: 133%; right:95px; border-radius: 50%; z-index:9999">
      </div>
      <div class="col-sm-2">
               <div class="top_middle">
                <img src="../assets/images/mlm/pps15_375x450.jpg" class="circle_img" alt="" style="position: relative; right:230px; width:48%;">
                <img src="../assets/images/mlm/1.jpg" class="d-block" alt="" width="10%" style="position: relative;  top:-21px; right:185px; border-radius: 50%;">
               </div>
   </div>
   <div class="col-sm-2">
    <img src="../assets/images/mlm/pps_9_375x450.jpg" class="circle_img" alt="" style="position: relative; right:222px; top: 135%; right:308px; width:44%; z-index:9999">
           <img src="../assets/images/mlm/4.jpg" alt="" width="10%" style="position: relative; top: 167%; left:-371px; border-radius: 50%; z-index:999999; right:115px">    
   </div>
   </div>
  
 <div class="row">  
  <div class="col-sm-1"></div>
   <div class="col-sm-11 cont">
    <img src="../assets/images/mlm/pie10.png" class="w-100 d-block" alt="" id="pie_small">
       <div class="centered_img"><img src="../assets/images/mlm/pps_8_1_828x842.jpg" class="w-25 d-block circle_inside" alt=""></div>
      <div class="centered">YOU</div>
  </div>
  </div>
  

<div class="row">
  <div class="col-sm-3"></div>
  <div class="col-sm-2">
<img src="../assets/images/mlm/5.jpg" class="d-block " alt="" width="10%" style="position: relative;  top:-42%; left:-80px; border-radius: 50%; z-index:99999999;">
      <img src="../assets/images/mlm/pps11.jpg" class="circle_img" alt="" style="position: relative; left: -115px; top:-184px; width:45%">
  </div>
  <div class="col-sm-2">
     <div class="bottom_middle">
               <img src="../assets/images/mlm/2.jpg" class="d-block" alt="" width="10%" style="position: relative; top:21px;  left:45px; border-radius:50%; z-index:999999">
        <img src="../assets/images/mlm/pps3.jpg" class="circle_img" alt="" style="position: relative; left:-2px; border-radius:50%">
      </div>
  </div>
  <div class="col-sm-2">
 <div class="bottom_right">
    <img src="../assets/images/mlm/6.jpg" class="d-block" alt="" width="10%" style="position: absolute; top: 83%; left:20px; border-radius: 50%; border-radius:50%; z-index:999999">
    <img src="../assets/images/mlm/pps2.jpg" class="circle_img" alt="" style="position: relative; right:25px; width:46%">
  </div>
  </div>
</div>